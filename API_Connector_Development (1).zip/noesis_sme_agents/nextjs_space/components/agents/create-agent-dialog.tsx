
"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Loader2, Search, BarChart3, PenTool } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'
import type { Agent } from './agents-dashboard'

interface CreateAgentDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAgentCreated: (agent: Agent) => void
}

const agentTypes = [
  {
    value: 'RESEARCH',
    label: 'Research Agent',
    description: 'Specialized in information gathering, data research, and comprehensive analysis',
    icon: Search,
    color: 'from-blue-500 to-cyan-500',
    features: ['Web Research', 'Data Gathering', 'Source Validation', 'Report Generation']
  },
  {
    value: 'ANALYSIS',
    label: 'Analysis Agent', 
    description: 'Expert in data interpretation, pattern recognition, and strategic insights',
    icon: BarChart3,
    color: 'from-green-500 to-emerald-500',
    features: ['Statistical Analysis', 'Pattern Recognition', 'Data Visualization', 'Insights Generation']
  },
  {
    value: 'CONTENT_GENERATION',
    label: 'Content Generation Agent',
    description: 'Creative agent for content creation, writing, and communication tasks',
    icon: PenTool,
    color: 'from-purple-500 to-pink-500',
    features: ['Creative Writing', 'Marketing Copy', 'Technical Documentation', 'Content Strategy']
  }
]

export function CreateAgentDialog({ open, onOpenChange, onAgentCreated }: CreateAgentDialogProps) {
  const [isCreating, setIsCreating] = useState(false)
  const [selectedType, setSelectedType] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    agentType: '',
    configuration: {}
  })
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.name.trim() || !selectedType) {
      toast({
        title: "Validation Error",
        description: "Please provide a name and select an agent type",
        variant: "destructive",
      })
      return
    }

    setIsCreating(true)
    
    try {
      const selectedConfig = agentTypes.find(t => t.value === selectedType)
      const defaultConfiguration = {
        model: 'gpt-4.1-mini',
        temperature: selectedType === 'CONTENT_GENERATION' ? 0.7 : 0.3,
        maxTokens: 4000,
        systemPrompt: getSystemPrompt(selectedType),
        features: selectedConfig?.features || [],
        specialty: selectedType.toLowerCase()
      }

      const response = await fetch('/api/agents', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name.trim(),
          description: formData.description.trim() || null,
          agentType: selectedType,
          configuration: defaultConfiguration
        }),
      })

      if (response.ok) {
        const { agent } = await response.json()
        onAgentCreated(agent)
        
        // Reset form
        setFormData({
          name: '',
          description: '',
          agentType: '',
          configuration: {}
        })
        setSelectedType('')
      } else {
        const error = await response.json()
        throw new Error(error.error || 'Failed to create agent')
      }
    } catch (error) {
      console.error('Error creating agent:', error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create agent",
        variant: "destructive",
      })
    } finally {
      setIsCreating(false)
    }
  }

  const getSystemPrompt = (agentType: string) => {
    switch (agentType) {
      case 'RESEARCH':
        return 'You are a research specialist AI agent. Your primary function is to conduct thorough research on any topic, gather relevant information from multiple perspectives, and provide comprehensive, well-structured reports. You excel at finding credible sources, analyzing data, and presenting findings in a clear, organized manner.'
      case 'ANALYSIS':
        return 'You are an analytical AI specialist focused on data analysis, pattern recognition, and insight generation. Your expertise includes statistical analysis, trend identification, data visualization recommendations, and strategic business insights. You provide actionable recommendations based on thorough data examination.'
      case 'CONTENT_GENERATION':
        return 'You are a creative content generation specialist. Your role is to create engaging, high-quality content across various formats including articles, marketing copy, creative writing, technical documentation, and social media content. You adapt your tone, style, and approach based on the target audience and content requirements.'
      default:
        return 'You are a helpful AI assistant.'
    }
  }

  const selectedTypeConfig = agentTypes.find(t => t.value === selectedType)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Create New AI Agent
          </DialogTitle>
          <DialogDescription>
            Choose the type of AI agent and configure it for your specific needs
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Agent Type Selection */}
          <div className="space-y-3">
            <Label className="text-base font-semibold">Agent Type</Label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {agentTypes.map((type) => {
                const Icon = type.icon
                return (
                  <motion.div
                    key={type.value}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Card 
                      className={cn(
                        "cursor-pointer transition-all hover:shadow-md border-2",
                        selectedType === type.value 
                          ? "border-primary ring-2 ring-primary/20" 
                          : "border-muted hover:border-primary/30"
                      )}
                      onClick={() => setSelectedType(type.value)}
                    >
                      <CardHeader className="pb-3">
                        <div className="flex items-center space-x-2">
                          <div className={cn(
                            "p-2 rounded-lg bg-gradient-to-r text-white",
                            type.color
                          )}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <CardTitle className="text-base">{type.label}</CardTitle>
                        </div>
                        <CardDescription className="text-sm">
                          {type.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <div className="flex flex-wrap gap-1">
                          {type.features.slice(0, 2).map((feature) => (
                            <Badge key={feature} variant="secondary" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                          {type.features.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{type.features.length - 2} more
                            </Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>

          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Agent Name *</Label>
              <Input
                id="name"
                placeholder="e.g., Research Assistant Pro"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Selected Type</Label>
              <div className="flex items-center space-x-2 p-3 bg-muted rounded-md">
                {selectedTypeConfig ? (
                  <>
                    <div className={cn(
                      "p-1 rounded bg-gradient-to-r text-white",
                      selectedTypeConfig.color
                    )}>
                      <selectedTypeConfig.icon className="h-3 w-3" />
                    </div>
                    <span className="text-sm font-medium">{selectedTypeConfig.label}</span>
                  </>
                ) : (
                  <span className="text-sm text-muted-foreground">No type selected</span>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe what this agent will help you with..."
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
            />
          </div>

          {/* Features Preview */}
          {selectedTypeConfig && (
            <div className="space-y-3">
              <Label className="text-base font-semibold">Agent Capabilities</Label>
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="flex flex-wrap gap-2">
                  {selectedTypeConfig.features.map((feature) => (
                    <Badge key={feature} variant="secondary">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isCreating || !selectedType}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              {isCreating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating Agent...
                </>
              ) : (
                'Create Agent'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
