
"use client"

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { 
  MoreVertical, 
  MessageSquare, 
  Settings, 
  Trash2, 
  Activity, 
  Bot,
  Search,
  BarChart3,
  PenTool
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import type { Agent } from './agents-dashboard'

interface AgentCardProps {
  agent: Agent
  onDeleted: (agentId: string) => void
}

const agentTypeConfig = {
  RESEARCH: {
    icon: Search,
    color: 'from-blue-500 to-cyan-500',
    bgColor: 'bg-blue-50 dark:bg-blue-950',
    label: 'Research Agent'
  },
  ANALYSIS: {
    icon: BarChart3,
    color: 'from-green-500 to-emerald-500',
    bgColor: 'bg-green-50 dark:bg-green-950',
    label: 'Analysis Agent'
  },
  CONTENT_GENERATION: {
    icon: PenTool,
    color: 'from-purple-500 to-pink-500',
    bgColor: 'bg-purple-50 dark:bg-purple-950',
    label: 'Content Generation Agent'
  }
}

export function AgentCard({ agent, onDeleted }: AgentCardProps) {
  const [isDeleting, setIsDeleting] = useState(false)
  const { toast } = useToast()
  const config = agentTypeConfig[agent.agentType]
  const Icon = config.icon

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this agent?')) {
      return
    }

    setIsDeleting(true)
    try {
      const response = await fetch(`/api/agents/${agent.id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        onDeleted(agent.id)
      } else {
        throw new Error('Failed to delete agent')
      }
    } catch (error) {
      console.error('Error deleting agent:', error)
      toast({
        title: "Error",
        description: "Failed to delete agent",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <motion.div
      whileHover={{ y: -2, scale: 1.01 }}
      transition={{ duration: 0.2 }}
    >
      <Card className={cn(
        "group cursor-pointer transition-all duration-200 hover:shadow-lg border-2 hover:border-primary/20",
        config.bgColor
      )}>
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              <div className={cn(
                "p-2 rounded-lg bg-gradient-to-r text-white",
                config.color
              )}>
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <CardTitle className="text-lg font-semibold group-hover:text-primary transition-colors">
                  {agent.name}
                </CardTitle>
                <Badge variant="secondary" className="text-xs mt-1">
                  {config.label}
                </Badge>
              </div>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href={`/chat?agent=${agent.id}`} className="cursor-pointer">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Open Chat
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href={`/agents/${agent.id}/settings`} className="cursor-pointer">
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={handleDelete} 
                  disabled={isDeleting}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          {agent.description && (
            <CardDescription className="mt-2 line-clamp-2">
              {agent.description}
            </CardDescription>
          )}
        </CardHeader>
        
        <CardContent className="pt-0">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <MessageSquare className="h-3 w-3" />
                <span>{agent._count.conversations}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Activity className="h-3 w-3" />
                <span>{agent._count.traces}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-1">
              <div className={cn(
                "h-2 w-2 rounded-full",
                agent.isActive ? "bg-green-500" : "bg-gray-400"
              )} />
              <span className="text-xs">
                {agent.isActive ? 'Active' : 'Inactive'}
              </span>
            </div>
          </div>
          
          <div className="mt-4 flex space-x-2">
            <Button asChild size="sm" className="flex-1">
              <Link href={`/chat?agent=${agent.id}`}>
                <MessageSquare className="mr-2 h-3 w-3" />
                Chat
              </Link>
            </Button>
            <Button asChild variant="outline" size="sm">
              <Link href={`/agents/${agent.id}`}>
                View Details
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
