import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ChatLayout from '@/components/chat/ChatLayout';
import { useThemeProvider } from '@/hooks/useThemeProvider';
import { useChatMessages, ChatMessage } from '@/hooks/useChatMessages';
import { LLMConfig } from '@/types/chat';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';

const Index = () => {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useThemeProvider();
  const { messages, addMessage, updateMessage } = useChatMessages();
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [llmConfig, setLlmConfig] = useState<LLMConfig>({
    model: 'gpt-3.5-turbo',
    temperature: 0.7,
    maxTokens: 1000,
    topP: 1,
    endpoint: '/api/chat'
  });
  
  const [systemPrompt, setSystemPrompt] = useState("You are a Noesis Agent, an advanced AI assistant. You're knowledgeable, thoughtful, and aim to be helpful while being honest about what you do and don't know.");

  // Check authentication
  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
      
      if (!session) {
        navigate('/auth');
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  // Load saved configuration from localStorage
  useEffect(() => {
    const savedConfig = localStorage.getItem('llmConfig');
    if (savedConfig) {
      try {
        setLlmConfig(JSON.parse(savedConfig));
      } catch (error) {
        console.error('Failed to parse saved LLM config:', error);
      }
    }
    
    const savedPrompt = localStorage.getItem('systemPrompt');
    if (savedPrompt) {
      setSystemPrompt(savedPrompt);
    }
  }, []);

  // Save configuration to localStorage
  useEffect(() => {
    localStorage.setItem('llmConfig', JSON.stringify(llmConfig));
  }, [llmConfig]);

  useEffect(() => {
    localStorage.setItem('systemPrompt', systemPrompt);
  }, [systemPrompt]);

  const simulateAIResponse = async (userMessage: string): Promise<string> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    // Simple mock responses based on user input
    const responses = [
      "I understand your question. Let me help you with that.",
      "That's an interesting point. Here's what I think about it...",
      "I'd be happy to assist you with this. Based on what you've told me...",
      "Thank you for sharing that with me. Here's my perspective...",
      "I can help you explore this topic further. Consider this approach...",
      "That's a great question! Let me break this down for you...",
    ];
    
    if (userMessage.toLowerCase().includes('hello') || userMessage.toLowerCase().includes('hi')) {
      return "Hello! I'm a Noesis Agent, your advanced AI assistant. How can I help you today?";
    }
    
    if (userMessage.toLowerCase().includes('help')) {
      return "I'm here to help! You can ask me questions, have conversations, get explanations on various topics, help with writing, analysis, math, coding, and much more. What would you like assistance with?";
    }
    
    return responses[Math.floor(Math.random() * responses.length)] + "\n\nThis is a demo response. In a real implementation, this would connect to an actual AI API like OpenAI's GPT or Anthropic's Claude API.";
  };

  const handleSendMessage = async (messageContent: string, attachments?: File[]) => {
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    // Handle attachments
    if (attachments && attachments.length > 0) {
      toast({
        title: "Files Processing",
        description: `Processing ${attachments.length} file(s)...`,
      });
    }

    // Add user message
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      content: messageContent + (attachments?.length ? ` [${attachments.length} file(s) attached]` : ''),
      timestamp,
      status: 'sent'
    };
    addMessage(userMessage);

    // Add AI message with sending status
    const aiMessageId = `ai-${Date.now()}`;
    const aiMessage: ChatMessage = {
      id: aiMessageId,
      sender: 'ai',
      content: '',
      timestamp,
      status: 'sending'
    };
    addMessage(aiMessage);

    try {
      const response = await simulateAIResponse(messageContent);
      
      // Update AI message with response
      updateMessage(aiMessageId, {
        content: response,
        status: 'sent',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });
      
    } catch (error) {
      console.error("Error getting AI response:", error);
      updateMessage(aiMessageId, {
        content: "I'm sorry, I encountered an error while processing your message. Please try again.",
        status: 'error'
      });
      
      toast({
        title: "Error",
        description: "Failed to get AI response. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="h-screen">
      <ChatLayout
        theme={theme}
        toggleTheme={toggleTheme}
        messages={messages}
        onSendMessage={handleSendMessage}
        llmConfig={llmConfig}
        setLlmConfig={setLlmConfig}
        systemPrompt={systemPrompt}
        setSystemPrompt={setSystemPrompt}
      />
    </div>
  );
};

export default Index;
