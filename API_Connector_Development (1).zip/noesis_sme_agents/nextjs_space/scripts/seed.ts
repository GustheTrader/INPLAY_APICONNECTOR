
import { PrismaClient, AgentType, SubscriptionTier, ThemePreference, TransactionType, MessageRole } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Starting seed process...')

  // Create the required test admin account
  const hashedPassword = await bcrypt.hash('johndoe123', 12)
  
  const adminUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      name: 'John Doe',
      password: hashedPassword,
      credits: 10000,
      subscriptionTier: SubscriptionTier.PREMIUM,
      themePreference: ThemePreference.DARK,
      isAdmin: true,
    },
  })

  // Create sample users for testing
  const users = await Promise.all([
    prisma.user.upsert({
      where: { email: 'alice@research.com' },
      update: {},
      create: {
        email: 'alice@research.com',
        name: 'Alice Researcher',
        password: await bcrypt.hash('password123', 12),
        credits: 5000,
        subscriptionTier: SubscriptionTier.BASIC,
        themePreference: ThemePreference.LIGHT,
      },
    }),
    prisma.user.upsert({
      where: { email: 'bob@analyst.com' },
      update: {},
      create: {
        email: 'bob@analyst.com',
        name: 'Bob Analyst',
        password: await bcrypt.hash('password123', 12),
        credits: 3000,
        subscriptionTier: SubscriptionTier.FREE,
        themePreference: ThemePreference.SYSTEM,
      },
    }),
  ])

  console.log('✅ Users created')

  // Create sample agents for all three types
  const sampleAgents = [
    {
      userId: adminUser.id,
      agentType: AgentType.RESEARCH,
      name: 'Research Master',
      description: 'Advanced research agent for comprehensive information gathering and analysis',
      configuration: {
        model: 'gpt-4.1-mini',
        temperature: 0.3,
        maxTokens: 4000,
        systemPrompt: 'You are a research specialist AI agent. Your primary function is to conduct thorough research on any topic, gather relevant information from multiple perspectives, and provide comprehensive, well-structured reports. You excel at finding credible sources, analyzing data, and presenting findings in a clear, organized manner.',
        features: ['Web Search', 'Source Validation', 'Report Generation', 'Data Analysis'],
        specialty: 'information_gathering',
      },
    },
    {
      userId: adminUser.id,
      agentType: AgentType.ANALYSIS,
      name: 'Data Analyzer Pro',
      description: 'Expert analysis agent for complex data interpretation and insights',
      configuration: {
        model: 'gpt-4.1-mini',
        temperature: 0.2,
        maxTokens: 3500,
        systemPrompt: 'You are an analytical AI specialist focused on data analysis, pattern recognition, and insight generation. Your expertise includes statistical analysis, trend identification, data visualization recommendations, and strategic business insights. You provide actionable recommendations based on thorough data examination.',
        features: ['Statistical Analysis', 'Pattern Recognition', 'Trend Analysis', 'Business Intelligence'],
        specialty: 'data_interpretation',
      },
    },
    {
      userId: adminUser.id,
      agentType: AgentType.CONTENT_GENERATION,
      name: 'Content Creator Elite',
      description: 'Creative content generation agent for various writing and creative tasks',
      configuration: {
        model: 'gpt-4.1-mini',
        temperature: 0.7,
        maxTokens: 4000,
        systemPrompt: 'You are a creative content generation specialist. Your role is to create engaging, high-quality content across various formats including articles, marketing copy, creative writing, technical documentation, and social media content. You adapt your tone, style, and approach based on the target audience and content requirements.',
        features: ['Article Writing', 'Marketing Copy', 'Creative Writing', 'Technical Docs'],
        specialty: 'content_creation',
      },
    },
    {
      userId: users[0].id,
      agentType: AgentType.RESEARCH,
      name: 'Academic Researcher',
      description: 'Specialized research agent for academic and scientific topics',
      configuration: {
        model: 'gpt-4.1-mini',
        temperature: 0.25,
        maxTokens: 3000,
        systemPrompt: 'You are an academic research assistant specialized in scientific and scholarly research. You help with literature reviews, hypothesis formation, research methodology, and academic writing.',
        features: ['Literature Review', 'Citation Management', 'Academic Writing'],
        specialty: 'academic_research',
      },
    },
    {
      userId: users[1].id,
      agentType: AgentType.ANALYSIS,
      name: 'Business Intelligence',
      description: 'Business-focused analysis agent for market research and strategy',
      configuration: {
        model: 'gpt-4.1-mini',
        temperature: 0.3,
        maxTokens: 3500,
        systemPrompt: 'You are a business intelligence analyst focused on market analysis, competitive research, and strategic planning. You provide data-driven insights for business decision making.',
        features: ['Market Analysis', 'Competitive Intelligence', 'Strategic Planning'],
        specialty: 'business_analysis',
      },
    },
  ]

  const agents = await Promise.all(
    sampleAgents.map(agent => 
      prisma.agent.create({
        data: agent,
      })
    )
  )

  console.log('✅ Sample agents created')

  // Create sample conversations and messages
  const conversation1 = await prisma.conversation.create({
    data: {
      agentId: agents[0].id,
      userId: adminUser.id,
      title: 'Market Research Analysis',
    },
  })

  const conversation2 = await prisma.conversation.create({
    data: {
      agentId: agents[1].id,
      userId: adminUser.id,
      title: 'Data Analysis Session',
    },
  })

  // Add sample messages to conversations
  await prisma.message.createMany({
    data: [
      {
        conversationId: conversation1.id,
        role: MessageRole.USER,
        content: 'Can you research the current trends in AI and machine learning for 2024?',
        creditsUsed: 0,
      },
      {
        conversationId: conversation1.id,
        role: MessageRole.ASSISTANT,
        content: 'I\'ll help you research the current AI and machine learning trends for 2024. Here are the key trends I\'ve identified:\n\n1. **Large Language Models (LLMs) Evolution**: Continued advancement in model capabilities with focus on efficiency and specialized applications.\n\n2. **Multimodal AI**: Integration of text, image, and audio processing in single models.\n\n3. **Edge AI**: Deployment of AI models on edge devices for real-time processing.\n\n4. **AI Governance & Ethics**: Increased focus on responsible AI development and deployment.\n\n5. **Industry-Specific AI Solutions**: Customized AI applications for healthcare, finance, and manufacturing.',
        creditsUsed: 45,
      },
      {
        conversationId: conversation2.id,
        role: MessageRole.USER,
        content: 'Analyze the performance metrics from our Q3 sales data',
        creditsUsed: 0,
      },
      {
        conversationId: conversation2.id,
        role: MessageRole.ASSISTANT,
        content: 'I\'d be happy to analyze your Q3 sales performance metrics. To provide a comprehensive analysis, I would need access to your specific sales data. However, I can outline the key metrics I would examine:\n\n**Revenue Metrics:**\n- Total revenue vs. targets\n- Year-over-year growth\n- Month-over-month trends\n\n**Performance Indicators:**\n- Conversion rates\n- Average deal size\n- Sales cycle length\n- Customer acquisition cost\n\nPlease provide your Q3 sales data, and I\'ll give you detailed insights and recommendations.',
        creditsUsed: 35,
      },
    ],
  })

  console.log('✅ Sample conversations created')

  // Create sample credit transactions
  await prisma.creditTransaction.createMany({
    data: [
      {
        userId: adminUser.id,
        amount: 10000,
        type: TransactionType.CREDIT_PURCHASE,
        description: 'Premium subscription credits',
        reference: 'premium-subscription-001',
      },
      {
        userId: adminUser.id,
        amount: -45,
        type: TransactionType.CREDIT_USAGE,
        description: 'Research agent conversation',
        reference: conversation1.id,
      },
      {
        userId: adminUser.id,
        amount: -35,
        type: TransactionType.CREDIT_USAGE,
        description: 'Analysis agent conversation',
        reference: conversation2.id,
      },
      {
        userId: users[0].id,
        amount: 5000,
        type: TransactionType.CREDIT_PURCHASE,
        description: 'Basic subscription credits',
        reference: 'basic-subscription-001',
      },
      {
        userId: users[1].id,
        amount: 1000,
        type: TransactionType.BONUS_CREDITS,
        description: 'Welcome bonus credits',
      },
    ],
  })

  console.log('✅ Sample credit transactions created')

  // Create sample traces for monitoring
  await prisma.trace.createMany({
    data: [
      {
        userId: adminUser.id,
        agentId: agents[0].id,
        request: {
          message: 'Can you research the current trends in AI and machine learning for 2024?',
          model: 'gpt-4.1-mini',
          temperature: 0.3,
        },
        response: {
          content: 'Research response content...',
          tokensUsed: 450,
          model: 'gpt-4.1-mini',
        },
        duration: 2340,
        tokensUsed: 450,
        success: true,
      },
      {
        userId: adminUser.id,
        agentId: agents[1].id,
        request: {
          message: 'Analyze the performance metrics from our Q3 sales data',
          model: 'gpt-4.1-mini',
          temperature: 0.2,
        },
        response: {
          content: 'Analysis response content...',
          tokensUsed: 380,
          model: 'gpt-4.1-mini',
        },
        duration: 1890,
        tokensUsed: 380,
        success: true,
      },
      {
        userId: users[0].id,
        agentId: agents[3].id,
        request: {
          message: 'Help me with a literature review on climate change',
          model: 'gpt-4.1-mini',
          temperature: 0.25,
        },
        response: null,
        duration: 0,
        tokensUsed: 0,
        success: false,
        error: 'Rate limit exceeded',
      },
    ],
  })

  console.log('✅ Sample traces created')

  // Display seeded data summary
  const userCount = await prisma.user.count()
  const agentCount = await prisma.agent.count()
  const conversationCount = await prisma.conversation.count()
  const messageCount = await prisma.message.count()
  const traceCount = await prisma.trace.count()
  const transactionCount = await prisma.creditTransaction.count()

  console.log('\n🎉 Database seeded successfully!')
  console.log('═══════════════════════════════════')
  console.log(`👥 Users: ${userCount}`)
  console.log(`🤖 Agents: ${agentCount}`)
  console.log(`💬 Conversations: ${conversationCount}`)
  console.log(`📝 Messages: ${messageCount}`)
  console.log(`📊 Traces: ${traceCount}`)
  console.log(`💰 Credit Transactions: ${transactionCount}`)
  console.log('═══════════════════════════════════')
  
  console.log('\n🔐 Test Accounts:')
  console.log('Admin: john@doe.com / johndoe123')
  console.log('User 1: alice@research.com / password123')
  console.log('User 2: bob@analyst.com / password123')
}

main()
  .catch((e) => {
    console.error('Error during seed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
