import NextAuth, { DefaultSession } from "next-auth"

declare module "next-auth" {
  /**
   * Extended Session interface with custom user properties
   */
  interface Session {
    user: {
      id: string
      email: string
      name?: string | null
      image?: string | null
      credits: number
      subscriptionTier: string
      themePreference: string
      isAdmin: boolean
    } & DefaultSession["user"]
  }

  /**
   * Extended User interface returned from authorize
   */
  interface User {
    id: string
    email: string
    name?: string | null
    credits: number
    subscriptionTier: string
    themePreference: string
    isAdmin: boolean
  }
}

declare module "next-auth/jwt" {
  /**
   * Extended JWT interface with custom token properties
   */
  interface JWT {
    sub?: string
    credits?: number
    subscriptionTier?: string
    themePreference?: string
    isAdmin?: boolean
  }
}
