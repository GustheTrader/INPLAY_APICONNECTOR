
"use client"

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useSearchParams } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Navigation } from '@/components/ui/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { 
  Send, 
  Bot, 
  User, 
  Loader2, 
  MessageSquare,
  Sparkles 
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import { cn } from '@/lib/utils'

interface Message {
  id: string
  role: 'USER' | 'ASSISTANT' | 'SYSTEM'
  content: string
  creditsUsed: number
  createdAt: string
}

interface Agent {
  id: string
  name: string
  agentType: string
  description: string | null
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null)
  const [agents, setAgents] = useState<Agent[]>([])
  const [conversationId, setConversationId] = useState<string | null>(null)
  
  const { data: session } = useSession() || {}
  const searchParams = useSearchParams()
  const initialAgentId = searchParams?.get('agent')
  const { toast } = useToast()
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await fetch('/api/agents')
        if (response.ok) {
          const data = await response.json()
          setAgents(data.agents || [])
          
          // Auto-select agent if provided in URL
          if (initialAgentId) {
            const agent = data.agents.find((a: Agent) => a.id === initialAgentId)
            if (agent) {
              setSelectedAgent(agent)
            }
          }
        }
      } catch (error) {
        console.error('Error fetching agents:', error)
      }
    }

    fetchAgents()
  }, [initialAgentId])

  const sendMessage = async () => {
    if (!inputValue.trim() || !selectedAgent || isLoading) return

    const userMessage = inputValue.trim()
    setInputValue('')
    setIsLoading(true)

    // Add user message to UI
    const tempUserMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'USER',
      content: userMessage,
      creditsUsed: 0,
      createdAt: new Date().toISOString()
    }
    setMessages(prev => [...prev, tempUserMessage])

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userMessage,
          agentId: selectedAgent.id,
          conversationId
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to send message')
      }

      // Handle streaming response
      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let assistantMessage = ''
      let assistantMessageId = `assistant-${Date.now()}`

      // Add placeholder assistant message
      const tempAssistantMessage: Message = {
        id: assistantMessageId,
        role: 'ASSISTANT',
        content: '',
        creditsUsed: 0,
        createdAt: new Date().toISOString()
      }
      setMessages(prev => [...prev, tempAssistantMessage])

      while (true) {
        const { done, value } = await reader?.read() || { done: true, value: undefined }
        if (done) break

        const chunk = decoder.decode(value)
        const lines = chunk.split('\n')

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6)
            
            try {
              const parsed = JSON.parse(data)
              
              if (parsed.type === 'completion') {
                setConversationId(parsed.conversationId)
                toast({
                  title: "Message sent",
                  description: `Used ${parsed.creditsUsed} credits`,
                })
                break
              } else if (parsed.type === 'error') {
                throw new Error(parsed.error)
              } else if (parsed.choices?.[0]?.delta?.content) {
                const content = parsed.choices[0].delta.content
                assistantMessage += content
                
                // Update assistant message in real-time
                setMessages(prev => prev.map(msg => 
                  msg.id === assistantMessageId 
                    ? { ...msg, content: assistantMessage }
                    : msg
                ))
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      console.error('Error sending message:', error)
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      })
      
      // Remove failed messages
      setMessages(prev => prev.filter(msg => 
        msg.id !== tempUserMessage.id && msg.id !== `assistant-${Date.now()}`
      ))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="h-screen flex flex-col">
      <Navigation />
      
      <div className="flex-1 flex">
        {/* Agent Sidebar */}
        <div className="w-80 border-r bg-background/50 backdrop-blur-sm p-4">
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Select an Agent</h3>
              <div className="space-y-2">
                {agents.map((agent) => (
                  <Card
                    key={agent.id}
                    className={cn(
                      "p-3 cursor-pointer transition-all",
                      selectedAgent?.id === agent.id 
                        ? "border-primary bg-primary/5" 
                        : "hover:bg-muted/50"
                    )}
                    onClick={() => {
                      setSelectedAgent(agent)
                      setMessages([])
                      setConversationId(null)
                    }}
                  >
                    <div className="flex items-center space-x-3">
                      <Bot className="h-5 w-5 text-primary" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{agent.name}</p>
                        <Badge variant="secondary" className="text-xs mt-1">
                          {agent.agentType.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    {agent.description && (
                      <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                        {agent.description}
                      </p>
                    )}
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {selectedAgent ? (
            <>
              {/* Chat Header */}
              <div className="border-b bg-background/80 backdrop-blur-sm p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Bot className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h2 className="font-semibold">{selectedAgent.name}</h2>
                    <p className="text-sm text-muted-foreground">
                      {selectedAgent.agentType.replace('_', ' ')} Agent
                    </p>
                  </div>
                  <div className="ml-auto flex items-center space-x-2">
                    <Badge variant="secondary">
                      Credits: {session?.user?.credits?.toLocaleString() ?? 0}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  <AnimatePresence>
                    {messages.map((message) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={cn(
                          "flex gap-3 max-w-4xl",
                          message.role === 'USER' ? "ml-auto flex-row-reverse" : ""
                        )}
                      >
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>
                            {message.role === 'USER' ? (
                              <User className="h-4 w-4" />
                            ) : (
                              <Bot className="h-4 w-4" />
                            )}
                          </AvatarFallback>
                        </Avatar>
                        
                        <Card className={cn(
                          "p-4 max-w-[80%]",
                          message.role === 'USER' 
                            ? "bg-primary text-primary-foreground" 
                            : "bg-muted"
                        )}>
                          <p className="whitespace-pre-wrap">{message.content}</p>
                          {message.creditsUsed > 0 && (
                            <div className="flex items-center space-x-1 mt-2 text-xs opacity-70">
                              <Sparkles className="h-3 w-3" />
                              <span>{message.creditsUsed} credits</span>
                            </div>
                          )}
                        </Card>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                  
                  {isLoading && (
                    <div className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback>
                          <Bot className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                      <Card className="p-4 bg-muted">
                        <div className="flex items-center space-x-2">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span>Thinking...</span>
                        </div>
                      </Card>
                    </div>
                  )}
                </div>
                <div ref={messagesEndRef} />
              </ScrollArea>

              {/* Input */}
              <div className="border-t bg-background/80 backdrop-blur-sm p-4">
                <div className="flex space-x-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={`Message ${selectedAgent.name}...`}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault()
                        sendMessage()
                      }
                    }}
                    disabled={isLoading}
                  />
                  <Button onClick={sendMessage} disabled={!inputValue.trim() || isLoading}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <MessageSquare className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Select an Agent to Start</h3>
                <p className="text-muted-foreground">
                  Choose an AI agent from the sidebar to begin your conversation
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
