
import { getServerSession } from 'next-auth'
import { NextRequest } from 'next/server'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { Prisma } from '@prisma/client'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      })
    }

    const { message, agentId, conversationId } = await req.json()

    // Validate required fields
    if (!message || !agentId) {
      return new Response(JSON.stringify({ error: 'Message and agent ID are required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      })
    }

    // Get agent and validate ownership
    const agent = await prisma.agent.findFirst({
      where: {
        id: agentId,
        userId: session.user.id,
        isActive: true
      }
    })

    if (!agent) {
      return new Response(JSON.stringify({ error: 'Agent not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' }
      })
    }

    // Check user credits
    const user = await prisma.user.findUnique({
      where: { id: session.user.id }
    })

    if (!user || user.credits < 10) { // Minimum 10 credits required
      return new Response(JSON.stringify({ error: 'Insufficient credits' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      })
    }

    // Get or create conversation
    let conversation: any = null
    if (conversationId) {
      conversation = await prisma.conversation.findFirst({
        where: {
          id: conversationId,
          userId: session.user.id,
          agentId: agentId
        },
        include: {
          messages: {
            orderBy: { createdAt: 'asc' },
            take: 10 // Last 10 messages for context
          }
        }
      })
    }

    if (!conversation) {
      conversation = await prisma.conversation.create({
        data: {
          agentId,
          userId: session.user.id,
          title: message.length > 50 ? message.substring(0, 50) + '...' : message
        },
        include: {
          messages: true
        }
      })
    }

    // Save user message
    await prisma.message.create({
      data: {
        conversationId: conversation.id,
        role: 'USER',
        content: message,
        creditsUsed: 0
      }
    })

    const startTime = Date.now()

    // Prepare messages for LLM API
    const config = agent.configuration as any
    const systemPrompt = config?.systemPrompt || 'You are a helpful AI assistant.'
    const messages = [
      { role: 'system', content: systemPrompt },
      ...conversation.messages.map((msg: any) => ({
        role: msg.role.toLowerCase(),
        content: msg.content
      })),
      { role: 'user', content: message }
    ]

    // Call LLM API with streaming
    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
      },
      body: JSON.stringify({
        model: config?.model || 'gpt-4.1-mini',
        messages: messages,
        stream: true,
        max_tokens: config?.maxTokens || 3000,
        temperature: config?.temperature || 0.7,
      }),
    })

    if (!response.ok) {
      throw new Error(`LLM API error: ${response.status}`)
    }

    let fullResponse = ''
    let tokensUsed = 0

    const stream = new ReadableStream({
      async start(controller) {
        const reader = response.body?.getReader()
        const decoder = new TextDecoder()
        const encoder = new TextEncoder()

        try {
          while (true) {
            const { done, value } = await reader?.read() || { done: true, value: undefined }
            if (done) break

            const chunk = decoder.decode(value)
            const lines = chunk.split('\n')

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6)
                if (data === '[DONE]') {
                  // Stream completed, save assistant message and update credits
                  const creditsUsed = Math.ceil(tokensUsed / 100) || 5 // Rough estimation
                  
                  await prisma.message.create({
                    data: {
                      conversationId: conversation.id,
                      role: 'ASSISTANT',
                      content: fullResponse,
                      creditsUsed: creditsUsed
                    }
                  })

                  // Deduct credits from user
                  await prisma.user.update({
                    where: { id: session.user.id },
                    data: { credits: { decrement: creditsUsed } }
                  })

                  // Create credit transaction
                  await prisma.creditTransaction.create({
                    data: {
                      userId: session.user.id,
                      amount: -creditsUsed,
                      type: 'CREDIT_USAGE',
                      description: `Chat with ${agent.name}`,
                      reference: conversation.id
                    }
                  })

                  // Create trace for monitoring
                  await prisma.trace.create({
                    data: {
                      userId: session.user.id,
                      agentId: agent.id,
                      request: { message, agentType: agent.agentType } as Prisma.InputJsonValue,
                      response: { content: fullResponse, tokensUsed } as Prisma.InputJsonValue,
                      duration: Date.now() - startTime,
                      tokensUsed,
                      success: true
                    }
                  })

                  // Send final data
                  const finalData = JSON.stringify({
                    type: 'completion',
                    conversationId: conversation.id,
                    creditsUsed,
                    tokensUsed
                  })
                  controller.enqueue(encoder.encode(`data: ${finalData}\n\n`))
                  return
                }

                try {
                  const parsed = JSON.parse(data)
                  const content = parsed.choices?.[0]?.delta?.content || ''
                  if (content) {
                    fullResponse += content
                    tokensUsed += 1 // Rough estimation
                    controller.enqueue(encoder.encode(`data: ${data}\n\n`))
                  }
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }
        } catch (error) {
          console.error('Stream error:', error)
          
          // Create error trace
          await prisma.trace.create({
            data: {
              userId: session.user.id,
              agentId: agent.id,
              request: { message, agentType: agent.agentType } as Prisma.InputJsonValue,
              response: Prisma.JsonNull,
              duration: Date.now() - startTime,
              tokensUsed: 0,
              success: false,
              error: error instanceof Error ? error.message : 'Unknown error'
            }
          })

          const errorData = JSON.stringify({
            type: 'error',
            error: 'Failed to generate response'
          })
          controller.enqueue(encoder.encode(`data: ${errorData}\n\n`))
          controller.error(error)
        } finally {
          controller.close()
        }
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })

  } catch (error) {
    console.error('Chat API error:', error)
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    })
  }
}
