
import { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { PrismaAdapter } from "@next-auth/prisma-adapter"
import { prisma } from "@/lib/db"
import bcrypt from "bcryptjs"

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials, req) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        const user = await prisma.user.findUnique({
          where: {
            email: credentials.email
          }
        })

        if (!user || !user.password) {
          return null
        }

        const isPasswordValid = await bcrypt.compare(
          credentials.password,
          user.password
        )

        if (!isPasswordValid) {
          return null
        }

        return {
          id: user.id,
          email: user.email,
          name: user.name ?? undefined,
          credits: user.credits,
          subscriptionTier: user.subscriptionTier,
          themePreference: user.themePreference,
          isAdmin: user.isAdmin,
        }
      }
    })
  ],
  session: {
    strategy: "jwt"
  },
  pages: {
    signIn: "/auth/signin",
  },
  callbacks: {
    async jwt({ token, user }) {
      // Add user properties to token on sign in
      if (user) {
        token.credits = (user as any).credits
        token.subscriptionTier = (user as any).subscriptionTier
        token.themePreference = (user as any).themePreference
        token.isAdmin = (user as any).isAdmin
      }
      return token
    },
    async session({ session, token }) {
      // Add token properties to session
      if (session.user) {
        session.user.id = token.sub as string
        session.user.credits = (token.credits as number) ?? 100
        session.user.subscriptionTier = (token.subscriptionTier as string) ?? 'FREE'
        session.user.themePreference = (token.themePreference as string) ?? 'LIGHT'
        session.user.isAdmin = (token.isAdmin as boolean) ?? false
      }
      return session
    }
  }
}
