# NFL Live Game Data API Research Report
**Date:** October 18, 2025  
**Project:** Minimal Single-Game INPLAY Agent for Real-Time NFL Tracking  
**Purpose:** Validation/Testing Project

---

## Executive Summary

After evaluating multiple NFL data APIs, **ESPN's unofficial API** is the recommended choice for this validation/testing project. It provides comprehensive real-time data without authentication requirements, making it ideal for rapid prototyping and testing. While unofficial, it offers all necessary features for live game tracking: real-time scores, play-by-play updates, game state, quarter information, and game events (touchdowns, field goals, etc.).

**Why ESPN API was selected:**
- ✅ **Completely Free** - No API keys or subscriptions required
- ✅ **No Authentication** - Immediate integration without setup overhead
- ✅ **Real-Time Updates** - Data updates during live games
- ✅ **Comprehensive Coverage** - All data points needed for INPLAY agent
- ✅ **JSON Format** - Easy to parse and integrate
- ✅ **Well-Documented** by community with extensive endpoint lists
- ✅ **Perfect for Validation** - Ideal for testing concepts before production

**Trade-offs:**
- ⚠️ Unofficial/Undocumented - No official support from ESPN
- ⚠️ Potential Instability - Endpoints could change without notice
- ⚠️ Terms of Service - May not be intended for public use

**For Production:** Consider MySportsFeeds (free for non-commercial) or paid services like SportsDataIO/Sportradar for guaranteed stability and support.

---

## Quick Start Integration Guide

### 1. Base URL
```
https://site.api.espn.com/apis/site/v2/sports/football/nfl/
```

### 2. No Authentication Required
Simply make HTTP GET requests to the endpoints. No API keys or headers needed.

### 3. Response Format
All responses are in JSON format. Simply parse the JSON response.

### 4. Rate Limits
Unknown (unofficial API), but reasonable request intervals are recommended. For live games, polling every 10-30 seconds is sufficient.

---

## Core Endpoints for INPLAY Agent

### 1. Live Scoreboard (Primary Endpoint)
**Purpose:** Get all live game scores and status in real-time

**Endpoint:**
```
GET https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard
```

**Query Parameters:**
- `dates` (optional): Filter by date in YYYYMMDD format (e.g., `20251018`)
- `limit` (optional): Number of results (default: 50, max: 1000)
- `week` (optional): Specific week number
- `seasontype` (optional): 1=preseason, 2=regular season, 3=postseason

**Example Request:**
```bash
curl "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=20251018&limit=100"
```

**Key Data Returned:**
- Live scores for both teams
- Game status (scheduled, in progress, final)
- Current quarter/period
- Time remaining in quarter
- Down and distance (if in progress)
- Recent scoring plays
- Team records
- Venue information
- TV broadcast info

**Sample Response Structure:**
```json
{
  "leagues": [{
    "season": { "year": 2025, "type": 2 },
    "calendarType": "week",
    "week": { "number": 7 }
  }],
  "season": { "year": 2025, "type": 2 },
  "week": { "number": 7 },
  "events": [
    {
      "id": "401671746",
      "date": "2025-10-18T17:00Z",
      "name": "Tampa Bay Buccaneers at Seattle Seahawks",
      "shortName": "TB @ SEA",
      "season": { "year": 2025, "type": 2 },
      "week": { "number": 7 },
      "competitions": [{
        "id": "401671746",
        "date": "2025-10-18T17:00Z",
        "attendance": 68740,
        "type": { "id": "1" },
        "timeValid": true,
        "neutralSite": false,
        "conferenceCompetition": false,
        "playByPlayAvailable": true,
        "recent": false,
        "venue": {
          "id": "3700",
          "fullName": "Lumen Field",
          "address": { "city": "Seattle", "state": "WA" }
        },
        "competitors": [
          {
            "id": "26",
            "uid": "s:20~l:28~t:26",
            "type": "team",
            "order": 0,
            "homeAway": "home",
            "team": {
              "id": "26",
              "uid": "s:20~l:28~t:26",
              "location": "Seattle",
              "name": "Seahawks",
              "abbreviation": "SEA",
              "displayName": "Seattle Seahawks",
              "shortDisplayName": "Seahawks",
              "color": "002244",
              "alternateColor": "69be28",
              "isActive": true,
              "logo": "https://a.espncdn.com/i/teamlogos/nfl/500/sea.png"
            },
            "score": "27",
            "linescores": [
              { "value": 7 },
              { "value": 10 },
              { "value": 7 },
              { "value": 3 }
            ],
            "statistics": [],
            "records": [
              { "name": "overall", "type": "total", "summary": "4-1", "displayValue": "4-1" }
            ]
          },
          {
            "id": "27",
            "uid": "s:20~l:28~t:27",
            "type": "team",
            "order": 1,
            "homeAway": "away",
            "team": {
              "id": "27",
              "location": "Tampa Bay",
              "name": "Buccaneers",
              "abbreviation": "TB",
              "displayName": "Tampa Bay Buccaneers",
              "shortDisplayName": "Buccaneers"
            },
            "score": "17",
            "linescores": [
              { "value": 0 },
              { "value": 7 },
              { "value": 7 },
              { "value": 3 }
            ],
            "records": [
              { "name": "overall", "type": "total", "summary": "3-2" }
            ]
          }
        ],
        "notes": [],
        "status": {
          "clock": 0,
          "displayClock": "0:00",
          "period": 4,
          "type": {
            "id": "3",
            "name": "STATUS_FINAL",
            "state": "post",
            "completed": true,
            "description": "Final",
            "detail": "Final",
            "shortDetail": "Final"
          }
        },
        "broadcasts": [
          {
            "market": "national",
            "names": ["FOX"]
          }
        ],
        "leaders": [
          {
            "name": "passingYards",
            "displayName": "Passing Leader",
            "shortDisplayName": "PASS",
            "abbreviation": "PYDS",
            "leaders": [{
              "displayValue": "245 YDS, 2 TD",
              "value": 245,
              "athlete": {
                "id": "4361741",
                "fullName": "Sam Darnold",
                "displayName": "Sam Darnold",
                "shortName": "S. Darnold"
              },
              "team": { "id": "26" }
            }]
          }
        ],
        "odds": [
          {
            "provider": { "id": "45", "name": "betmgm" },
            "details": "SEA -3.5",
            "overUnder": 44.5
          }
        ],
        "situation": {
          "lastPlay": {
            "id": "4016717462341",
            "type": { "id": "67", "text": "End of Game" },
            "text": "End Game",
            "scoreValue": 0,
            "team": { "id": "26" },
            "probability": {
              "tiePercentage": 0,
              "homeWinPercentage": 100,
              "awayWinPercentage": 0
            },
            "start": {
              "down": 1,
              "distance": 10,
              "yardLine": 75,
              "team": { "id": "27" }
            }
          }
        }
      }],
      "links": [{
        "language": "en-US",
        "rel": ["summary", "desktop", "event"],
        "href": "https://www.espn.com/nfl/game/_/gameId/401671746"
      }]
    }
  ]
}
```

**Polling Strategy:**
- For live games: Poll every 10-15 seconds
- For upcoming games: Poll every 5-10 minutes
- For completed games: Stop polling or reduce to hourly

---

### 2. Game Summary (Detailed Game Information)
**Purpose:** Get comprehensive game details including play-by-play, scoring summary, team stats

**Endpoint:**
```
GET https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event={EVENT_ID}
```

**Parameters:**
- `event` (required): Game ID from scoreboard (e.g., `401671746`)

**Example Request:**
```bash
curl "https://site.api.espn.com/apis/site/v2/sports/football/nfl/summary?event=401671746"
```

**Key Data Returned:**
- Complete box score
- Scoring plays with timestamps
- Team statistics (total yards, passing yards, rushing yards, turnovers, etc.)
- Drive summaries
- Key plays
- Game leaders
- Injury updates
- Weather conditions
- Referee information

**Sample Response Structure:**
```json
{
  "boxscore": {
    "teams": [{
      "team": {
        "id": "26",
        "displayName": "Seattle Seahawks"
      },
      "statistics": [
        { "name": "totalYards", "displayValue": "378", "label": "Total Yards" },
        { "name": "passingYards", "displayValue": "245", "label": "Passing Yards" },
        { "name": "rushingYards", "displayValue": "133", "label": "Rushing Yards" },
        { "name": "turnovers", "displayValue": "1", "label": "Turnovers" },
        { "name": "possessionTime", "displayValue": "31:24", "label": "Time of Possession" }
      ]
    }]
  },
  "scoringPlays": [
    {
      "id": "4016717461234",
      "type": { "id": "68", "text": "Touchdown" },
      "text": "Kenneth Walker III 15 yd run (Jason Myers kick)",
      "awayScore": 0,
      "homeScore": 7,
      "period": { "number": 1 },
      "clock": { "displayValue": "8:42" },
      "team": { "id": "26" },
      "scoringType": { "name": "touchdown", "displayName": "Touchdown", "abbreviation": "TD" }
    }
  ],
  "drives": {
    "previous": [{
      "id": "40167174612",
      "description": "8 plays, 75 yards, 4:18",
      "team": { "id": "26" },
      "start": {
        "period": { "number": 1 },
        "clock": { "displayValue": "13:00" },
        "yardLine": 25
      },
      "end": {
        "period": { "number": 1 },
        "clock": { "displayValue": "8:42" },
        "yardLine": 100
      },
      "timeElapsed": { "displayValue": "4:18" },
      "yards": 75,
      "plays": 8,
      "result": "TD"
    }]
  },
  "leaders": [{
    "name": "passingLeader",
    "displayName": "Passing",
    "leaders": [{
      "athlete": { "displayName": "Sam Darnold" },
      "displayValue": "18/25, 245 YDS, 2 TD, 1 INT"
    }]
  }]
}
```

---

### 3. Play-by-Play (Real-Time Game Events)
**Purpose:** Get detailed play-by-play data for live tracking

**Endpoint:**
```
GET https://sports.core.api.espn.com/v2/sports/football/leagues/nfl/events/{EVENT_ID}/competitions/{EVENT_ID}/plays?limit=300
```

**Parameters:**
- `{EVENT_ID}` (required): Game ID (same for both placeholders)
- `limit` (optional): Number of plays to return (default: 100, max: 300)

**Example Request:**
```bash
curl "https://sports.core.api.espn.com/v2/sports/football/leagues/nfl/events/401671746/competitions/401671746/plays?limit=300"
```

**Key Data Returned:**
- Play-by-play text descriptions
- Play type (pass, rush, punt, field goal, etc.)
- Yardage gained/lost
- Down and distance
- Field position
- Clock time
- Scoring plays
- Penalties
- Turnovers

**Sample Response Structure:**
```json
{
  "count": 156,
  "pageIndex": 1,
  "pageSize": 300,
  "pageCount": 1,
  "items": [{
    "$ref": "http://sports.core.api.espn.com/v2/sports/football/leagues/nfl/events/401671746/competitions/401671746/plays/4016717461234"
  }]
}
```

**Note:** This endpoint returns references to individual plays. You need to fetch each play URL for full details, or use the Game Summary endpoint which includes recent plays.

---

### 4. Live Game Drives
**Purpose:** Get drive information (sequence of plays)

**Endpoint:**
```
GET https://sports.core.api.espn.com/v2/sports/football/leagues/nfl/events/{EVENT_ID}/competitions/{EVENT_ID}/drives
```

**Example Request:**
```bash
curl "https://sports.core.api.espn.com/v2/sports/football/leagues/nfl/events/401671746/competitions/401671746/drives"
```

**Key Data Returned:**
- Drive start/end positions
- Number of plays in drive
- Total yards gained
- Time of possession
- Drive result (TD, FG, Punt, Turnover)

---

### 5. Team Roster & Depth Chart
**Purpose:** Get team rosters for player identification

**Endpoint:**
```
GET https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/{TEAM_ID}/roster
```

**Example Request:**
```bash
curl "https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/26/roster"
```

**Key Data Returned:**
- Player names and numbers
- Positions
- Height, weight
- College
- Experience

---

### 6. Team Schedule
**Purpose:** Get upcoming/past games for a team

**Endpoint:**
```
GET https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/{TEAM_ID}/schedule?season={YEAR}
```

**Example Request:**
```bash
curl "https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/26/schedule?season=2025"
```

---

### 7. Betting Odds
**Purpose:** Get current betting lines (spreads, totals, moneylines)

**Endpoint:**
```
GET https://sports.core.api.espn.com/v2/sports/football/leagues/nfl/events/{EVENT_ID}/competitions/{EVENT_ID}/odds
```

**Example Request:**
```bash
curl "https://sports.core.api.espn.com/v2/sports/football/leagues/nfl/events/401671746/competitions/401671746/odds"
```

**Key Data Returned:**
- Spread (e.g., SEA -3.5)
- Total (Over/Under)
- Moneyline odds
- Multiple sportsbook providers

---

## Complete API Endpoint Reference Table

| Endpoint | URL Pattern | Key Parameters | Update Frequency | Primary Use Case |
|----------|-------------|----------------|------------------|------------------|
| **Scoreboard** | `/scoreboard` | `dates`, `limit`, `week` | Real-time (10-15s) | Live scores, game status, quarter info |
| **Game Summary** | `/summary?event={ID}` | `event` | Real-time (15-30s) | Detailed game stats, scoring plays |
| **Play-by-Play** | `/events/{ID}/competitions/{ID}/plays` | `limit` | Real-time (10-15s) | Individual play details |
| **Drives** | `/events/{ID}/competitions/{ID}/drives` | None | Real-time (30s) | Drive summaries |
| **Odds** | `/events/{ID}/competitions/{ID}/odds` | None | Hourly/Real-time | Betting lines |
| **Team Roster** | `/teams/{ID}/roster` | None | Daily | Player identification |
| **Team Schedule** | `/teams/{ID}/schedule` | `season` | Daily | Upcoming games |

---

## Data Format Details

### Response Format
- **Content-Type:** `application/json`
- **Character Encoding:** UTF-8
- **Date Format:** ISO 8601 (e.g., `2025-10-18T17:00Z`)

### Game Status Types
```json
{
  "status": {
    "type": {
      "id": "1",  // Scheduled/Pre-game
      "id": "2",  // In Progress
      "id": "3",  // Final/Complete
      "state": "pre" | "in" | "post"
    }
  }
}
```

### Common Field Mappings
- **Event ID**: Unique identifier for each game (e.g., `401671746`)
- **Team ID**: 1-32 for NFL teams (e.g., `26` = Seahawks, `27` = Buccaneers)
- **Period**: Quarter number (1-4, 5 = Overtime)
- **Clock**: Time remaining in format "MM:SS"
- **Possession**: Team currently with the ball
- **Down**: Current down (1-4)
- **Distance**: Yards to first down or goal

---

## Update Frequency & Polling Strategy

### During Live Games
- **Scoreboard**: Poll every **10-15 seconds**
- **Game Summary**: Poll every **15-30 seconds**
- **Play-by-Play**: Poll every **10-15 seconds** (for real-time updates)

### Before Games
- **Scoreboard**: Poll every **5-10 minutes** (to detect kickoff)
- **Odds**: Poll every **30-60 minutes**

### After Games
- **Scoreboard**: Stop polling (or reduce to hourly for final stats updates)

### Important Notes
- Combine scoreboard + game summary for most efficient updates
- Use scoreboard to detect game state changes (kickoff, half-time, final)
- Only poll play-by-play when game status is "in progress"
- Cache static data (rosters, schedules) and update daily

---

## Rate Limits & Best Practices

### Rate Limiting
- **Unknown official limits** (unofficial API)
- Conservative recommendation: Max 6 requests per minute per endpoint
- Implement exponential backoff for errors

### Error Handling
```python
import time
import requests

def fetch_with_retry(url, max_retries=3):
    for attempt in range(max_retries):
        try:
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            if attempt == max_retries - 1:
                raise
            wait_time = 2 ** attempt  # Exponential backoff
            time.sleep(wait_time)
```

### Caching Strategy
```python
from datetime import datetime, timedelta
import json

class APICache:
    def __init__(self):
        self.cache = {}
        self.cache_duration = {
            'roster': timedelta(days=1),
            'schedule': timedelta(hours=6),
            'scoreboard': timedelta(seconds=15),
            'game_summary': timedelta(seconds=15)
        }
    
    def get(self, key, cache_type):
        if key in self.cache:
            data, timestamp = self.cache[key]
            if datetime.now() - timestamp < self.cache_duration[cache_type]:
                return data
        return None
    
    def set(self, key, data, cache_type):
        self.cache[key] = (data, datetime.now())
```

---

## Sample Integration Code (Python)

### Basic Game Tracker
```python
import requests
import time
from datetime import datetime

class NFLGameTracker:
    def __init__(self):
        self.base_url = "https://site.api.espn.com/apis/site/v2/sports/football/nfl"
        self.session = requests.Session()
    
    def get_live_scoreboard(self, date=None):
        """Get all games for a specific date"""
        url = f"{self.base_url}/scoreboard"
        params = {}
        if date:
            params['dates'] = date.strftime('%Y%m%d')
        params['limit'] = 100
        
        response = self.session.get(url, params=params, timeout=10)
        response.raise_for_status()
        return response.json()
    
    def get_game_summary(self, event_id):
        """Get detailed game information"""
        url = f"{self.base_url}/summary"
        params = {'event': event_id}
        
        response = self.session.get(url, params=params, timeout=10)
        response.raise_for_status()
        return response.json()
    
    def find_live_games(self):
        """Find all currently live games"""
        scoreboard = self.get_live_scoreboard()
        live_games = []
        
        for event in scoreboard.get('events', []):
            competition = event['competitions'][0]
            status = competition['status']['type']['state']
            
            if status == 'in':  # Game in progress
                live_games.append({
                    'id': event['id'],
                    'name': event['name'],
                    'home': competition['competitors'][0]['team']['displayName'],
                    'away': competition['competitors'][1]['team']['displayName'],
                    'home_score': competition['competitors'][0]['score'],
                    'away_score': competition['competitors'][1]['score'],
                    'quarter': competition['status']['period'],
                    'clock': competition['status']['displayClock'],
                    'situation': competition.get('situation', {})
                })
        
        return live_games
    
    def track_game(self, event_id, interval=15):
        """Track a single game with updates"""
        print(f"Starting game tracker for event {event_id}")
        
        while True:
            try:
                summary = self.get_game_summary(event_id)
                header = summary['header']
                competition = header['competitions'][0]
                status = competition['status']
                
                # Check if game is still in progress
                if status['type']['state'] != 'in':
                    print(f"Game ended: {status['type']['detail']}")
                    break
                
                # Display current game state
                home = competition['competitors'][0]
                away = competition['competitors'][1]
                
                print(f"\n{datetime.now().strftime('%H:%M:%S')}")
                print(f"Q{status['period']} - {status['displayClock']}")
                print(f"{away['team']['displayName']}: {away['score']}")
                print(f"{home['team']['displayName']}: {home['score']}")
                
                # Show current situation
                situation = competition.get('situation')
                if situation and 'lastPlay' in situation:
                    print(f"Last Play: {situation['lastPlay']['text']}")
                
                time.sleep(interval)
                
            except KeyboardInterrupt:
                print("\nStopping tracker...")
                break
            except Exception as e:
                print(f"Error: {e}")
                time.sleep(interval)

# Usage
if __name__ == "__main__":
    tracker = NFLGameTracker()
    
    # Find today's live games
    live_games = tracker.find_live_games()
    
    if live_games:
        print(f"Found {len(live_games)} live games:")
        for i, game in enumerate(live_games, 1):
            print(f"{i}. {game['name']} - Q{game['quarter']} {game['clock']}")
        
        # Track the first live game
        if live_games:
            tracker.track_game(live_games[0]['id'], interval=15)
    else:
        print("No live games currently")
```

### Event Parser for Betting Analysis
```python
class NFLEventParser:
    @staticmethod
    def parse_game_for_betting(game_summary):
        """Extract betting-relevant information from game summary"""
        header = game_summary['header']
        competition = header['competitions'][0]
        
        # Basic game info
        game_info = {
            'event_id': header['id'],
            'game_name': header['competitions'][0]['competitors'][0]['team']['displayName'] + ' vs ' + 
                        header['competitions'][0]['competitors'][1]['team']['displayName'],
            'status': competition['status']['type']['detail'],
            'quarter': competition['status']['period'],
            'clock': competition['status']['displayClock']
        }
        
        # Team scores and stats
        home_team = competition['competitors'][0]
        away_team = competition['competitors'][1]
        
        game_info['home'] = {
            'name': home_team['team']['displayName'],
            'score': int(home_team['score']),
            'record': home_team['records'][0]['summary'] if home_team.get('records') else 'N/A'
        }
        
        game_info['away'] = {
            'name': away_team['team']['displayName'],
            'score': int(away_team['score']),
            'record': away_team['records'][0]['summary'] if away_team.get('records') else 'N/A'
        }
        
        # Betting odds
        if 'odds' in competition:
            odds = competition['odds'][0] if competition['odds'] else None
            if odds:
                game_info['odds'] = {
                    'spread': odds.get('details', 'N/A'),
                    'total': odds.get('overUnder', 'N/A'),
                    'provider': odds.get('provider', {}).get('name', 'N/A')
                }
        
        # Scoring plays
        if 'scoringPlays' in game_summary:
            game_info['scoring_plays'] = []
            for play in game_summary['scoringPlays']:
                game_info['scoring_plays'].append({
                    'quarter': play['period']['number'],
                    'clock': play['clock']['displayValue'],
                    'team': play['team']['id'],
                    'type': play['scoringType']['name'],
                    'description': play['text'],
                    'home_score': play['homeScore'],
                    'away_score': play['awayScore']
                })
        
        # Box score stats
        if 'boxscore' in game_summary:
            for team_stats in game_summary['boxscore']['teams']:
                team_name = 'home' if team_stats['team']['id'] == home_team['team']['id'] else 'away'
                game_info[team_name]['stats'] = {}
                
                for stat in team_stats['statistics']:
                    game_info[team_name]['stats'][stat['name']] = {
                        'value': stat.get('displayValue', '0'),
                        'label': stat.get('label', stat['name'])
                    }
        
        return game_info

# Usage
parser = NFLEventParser()
tracker = NFLGameTracker()

game_summary = tracker.get_game_summary('401671746')
betting_analysis = parser.parse_game_for_betting(game_summary)

print(f"\n{betting_analysis['game_name']}")
print(f"Status: {betting_analysis['status']}")
print(f"{betting_analysis['away']['name']}: {betting_analysis['away']['score']}")
print(f"{betting_analysis['home']['name']}: {betting_analysis['home']['score']}")
if 'odds' in betting_analysis:
    print(f"Spread: {betting_analysis['odds']['spread']}")
    print(f"Total: {betting_analysis['odds']['total']}")
```

---

## Integration with INPLAY Agent

### Recommended Architecture
Based on the example report format (`NFL Week 5 Afternoon Games.md`), the INPLAY agent should:

1. **Poll Scoreboard** (every 10-15 seconds during live games)
   - Detect game status changes (kickoff, quarters, halftime, final)
   - Track current scores and quarter information
   - Monitor game clock

2. **Fetch Game Summary** (every 30 seconds during critical moments)
   - Get detailed statistics when major events occur
   - Pull scoring play descriptions
   - Update team stats

3. **Generate Betting Analysis**
   - Compare live scores vs. pre-game spreads
   - Calculate cover probability based on current score and time remaining
   - Track scoring pace vs. total (over/under)
   - Identify key momentum shifts

4. **Presentation Format** (matching example report style)
   ```
   Game Status: [In Progress/Final]
   Quarter: [1-4]
   Clock: [MM:SS]
   
   Score:
   Away Team: XX
   Home Team: XX
   
   Betting Lines:
   Spread: [TEAM -X.X]
   Current Status: [Covering/Not Covering by X points]
   
   Total: [O/U XX.X]
   Current Total: [XX points]
   Current Status: [Over/Under by X points]
   
   Recent Scoring Plays:
   - [Q1 - 8:42] Home Team - Touchdown (7-0)
   - [Q2 - 12:15] Away Team - Field Goal (7-3)
   
   Key Statistics:
   Home: [Total Yards, Passing Yards, Rushing Yards, Turnovers]
   Away: [Total Yards, Passing Yards, Rushing Yards, Turnovers]
   ```

### Data Refresh Strategy
```python
class INPLAYAgent:
    def __init__(self, event_id):
        self.event_id = event_id
        self.tracker = NFLGameTracker()
        self.last_update = None
        self.game_state = None
    
    def should_update(self):
        """Determine if we need to fetch new data"""
        if not self.last_update:
            return True
        
        # Update every 10 seconds during live games
        if self.game_state and self.game_state['status'] == 'in':
            return (datetime.now() - self.last_update).seconds >= 10
        
        # Update every 5 minutes for pre-game
        elif self.game_state and self.game_state['status'] == 'pre':
            return (datetime.now() - self.last_update).seconds >= 300
        
        return False
    
    def update_game_state(self):
        """Fetch latest game data"""
        summary = self.tracker.get_game_summary(self.event_id)
        self.game_state = self.parse_game_state(summary)
        self.last_update = datetime.now()
        return self.game_state
    
    def generate_betting_report(self):
        """Generate report in example format"""
        if not self.game_state:
            self.update_game_state()
        
        # Format output matching example report style
        report = f"""
# {self.game_state['game_name']}
**Status:** {self.game_state['status']}
**Quarter:** {self.game_state['quarter']}
**Clock:** {self.game_state['clock']}

## Score
{self.game_state['away']['name']}: {self.game_state['away']['score']}
{self.game_state['home']['name']}: {self.game_state['home']['score']}

## Betting Analysis
**Spread:** {self.game_state['odds']['spread']}
**Current Status:** {self.calculate_spread_status()}

**Total:** O/U {self.game_state['odds']['total']}
**Current Total:** {self.game_state['home']['score'] + self.game_state['away']['score']} points
**Current Status:** {self.calculate_total_status()}

## Recent Scoring Plays
{self.format_scoring_plays()}

## Key Statistics
**{self.game_state['home']['name']}:** {self.format_team_stats('home')}
**{self.game_state['away']['name']}:** {self.format_team_stats('away')}
"""
        return report
```

---

## Alternative APIs (For Future Consideration)

### 1. MySportsFeeds
- **Cost:** Free for non-commercial use (with attribution)
- **Authentication:** API key required (free account)
- **Pros:** Official API, reliable, comprehensive data
- **Cons:** Requires signup, non-commercial only
- **Best for:** Non-commercial projects needing stability
- **Website:** https://www.mysportsfeeds.com/

### 2. SportsDataIO
- **Cost:** Paid (free trial available)
- **Authentication:** API key required
- **Pros:** Professional-grade, excellent documentation, real-time data
- **Cons:** Expensive for production ($50-200+/month)
- **Best for:** Commercial applications
- **Website:** https://sportsdata.io/

### 3. Sportradar (Official NFL Partner)
- **Cost:** Enterprise pricing
- **Authentication:** API key required
- **Pros:** Official NFL data partner, highest quality, guaranteed uptime
- **Cons:** Very expensive, requires contract
- **Best for:** Large-scale commercial applications
- **Website:** https://developer.sportradar.com/

---

## Troubleshooting & Common Issues

### Issue 1: Empty Response
**Problem:** API returns `{"events": []}`
**Solution:** 
- Check date format (YYYYMMDD)
- Verify game is scheduled for that date
- Try removing date parameter to see all games

### Issue 2: 404 Not Found
**Problem:** Game summary returns 404
**Solution:**
- Verify event ID is correct
- Check if game exists in scoreboard first
- Some games may not have full data until kickoff

### Issue 3: Missing Play-by-Play
**Problem:** Play-by-play endpoint returns limited data
**Solution:**
- Use Game Summary endpoint instead (includes recent plays)
- Play-by-play may require dereferencing URLs
- Not all plays are immediately available during live games

### Issue 4: Stale Data
**Problem:** Scores not updating in real-time
**Solution:**
- Check polling interval (should be 10-15 seconds)
- Verify game status is "in progress"
- Clear cache if using caching layer
- ESPN may have 5-10 second delay from actual play

### Issue 5: Rate Limiting
**Problem:** Getting 429 errors or blocked requests
**Solution:**
- Reduce polling frequency
- Implement exponential backoff
- Use single connection pool (requests.Session())
- Cache static data (rosters, schedules)

---

## Testing & Validation Checklist

### Pre-Integration Testing
- [ ] Verify scoreboard endpoint returns data
- [ ] Test with current date parameter
- [ ] Confirm JSON parsing works correctly
- [ ] Test error handling for invalid event IDs
- [ ] Verify timeout handling

### Live Game Testing
- [ ] Poll scoreboard during live game
- [ ] Verify quarter and clock updates
- [ ] Check scoring play detection
- [ ] Monitor for missing data fields
- [ ] Test status transitions (kickoff → in progress → halftime → final)

### Data Validation
- [ ] Compare ESPN API data with ESPN.com website
- [ ] Verify score accuracy
- [ ] Check timestamp consistency
- [ ] Validate team IDs and names
- [ ] Confirm betting odds match published lines

### Performance Testing
- [ ] Measure API response times
- [ ] Test with multiple concurrent games
- [ ] Verify memory usage doesn't grow unbounded
- [ ] Check for connection leaks
- [ ] Monitor polling efficiency

---

## Appendix A: Complete Team ID Reference

| Team ID | Abbreviation | Team Name |
|---------|--------------|-----------|
| 1 | ATL | Atlanta Falcons |
| 2 | BUF | Buffalo Bills |
| 3 | CHI | Chicago Bears |
| 4 | CIN | Cincinnati Bengals |
| 5 | CLE | Cleveland Browns |
| 6 | DAL | Dallas Cowboys |
| 7 | DEN | Denver Broncos |
| 8 | DET | Detroit Lions |
| 9 | GB | Green Bay Packers |
| 10 | TEN | Tennessee Titans |
| 11 | IND | Indianapolis Colts |
| 12 | KC | Kansas City Chiefs |
| 13 | LV | Las Vegas Raiders |
| 14 | LAR | Los Angeles Rams |
| 15 | MIA | Miami Dolphins |
| 16 | MIN | Minnesota Vikings |
| 17 | NE | New England Patriots |
| 18 | NO | New Orleans Saints |
| 19 | NYG | New York Giants |
| 20 | NYJ | New York Jets |
| 21 | PHI | Philadelphia Eagles |
| 22 | ARI | Arizona Cardinals |
| 23 | PIT | Pittsburgh Steelers |
| 24 | LAC | Los Angeles Chargers |
| 25 | SF | San Francisco 49ers |
| 26 | SEA | Seattle Seahawks |
| 27 | TB | Tampa Bay Buccaneers |
| 28 | WSH | Washington Commanders |
| 29 | CAR | Carolina Panthers |
| 30 | JAX | Jacksonville Jaguars |
| 33 | BAL | Baltimore Ravens |
| 34 | HOU | Houston Texans |

---

## Appendix B: Season Type & Week Parameters

### Season Type Values
- `1` = Preseason
- `2` = Regular Season
- `3` = Postseason
- `4` = Off-season

### Week Numbers
- **Preseason:** Weeks 0-4
- **Regular Season:** Weeks 1-18
- **Postseason:**
  - Week 19: Wild Card Round
  - Week 20: Divisional Round
  - Week 21: Conference Championships
  - Week 22: Super Bowl

---

## Appendix C: Play Types & Event IDs

### Common Play Types
- `67` = End of Quarter
- `68` = Touchdown
- `59` = Field Goal (Good)
- `36` = Punt
- `52` = Kickoff
- `24` = Pass Completion
- `5` = Rush
- `36` = Sack
- `26` = Interception
- `29` = Fumble

### Scoring Types
- `touchdown` = 6 points (+ extra point/2-pt conversion)
- `field-goal` = 3 points
- `pat` = 1 point (extra point)
- `two-point-conversion` = 2 points
- `safety` = 2 points

---

## Appendix D: Example API Responses

### Sample Scoreboard Response (Condensed)
```json
{
  "leagues": [{"id": "28", "name": "National Football League", "abbreviation": "NFL"}],
  "season": {"year": 2025, "type": 2},
  "week": {"number": 7},
  "events": [{
    "id": "401671746",
    "date": "2025-10-18T17:00Z",
    "name": "Tampa Bay Buccaneers at Seattle Seahawks",
    "shortName": "TB @ SEA",
    "competitions": [{
      "status": {
        "clock": 845.0,
        "displayClock": "14:05",
        "period": 2,
        "type": {"id": "2", "name": "STATUS_IN_PROGRESS", "state": "in"}
      },
      "competitors": [
        {
          "homeAway": "home",
          "team": {"id": "26", "displayName": "Seattle Seahawks"},
          "score": "14",
          "linescores": [{"value": 7}, {"value": 7}]
        },
        {
          "homeAway": "away",
          "team": {"id": "27", "displayName": "Tampa Bay Buccaneers"},
          "score": "10",
          "linescores": [{"value": 3}, {"value": 7}]
        }
      ],
      "situation": {
        "possession": "26",
        "down": 2,
        "distance": 7,
        "yardLine": 65
      }
    }]
  }]
}
```

---

## Summary & Next Steps

### Implementation Roadmap

1. **Phase 1: Basic Integration** (Day 1)
   - Implement scoreboard polling
   - Parse game status and scores
   - Display basic game information

2. **Phase 2: Detailed Tracking** (Day 2-3)
   - Add game summary fetching
   - Parse scoring plays
   - Extract team statistics
   - Implement betting analysis

3. **Phase 3: Real-Time Updates** (Day 3-4)
   - Optimize polling intervals
   - Add event detection (touchdowns, field goals)
   - Implement momentum tracking
   - Generate formatted reports

4. **Phase 4: Testing & Validation** (Day 5)
   - Test with live games
   - Validate data accuracy
   - Performance optimization
   - Error handling refinement

### Key Advantages of ESPN API for Validation Project
1. **Zero Setup Time** - No registration, no API keys
2. **Immediate Testing** - Start coding right away
3. **Complete Data** - All necessary fields for INPLAY agent
4. **Real-Time Updates** - Live game tracking capability
5. **Free Forever** - No costs during validation phase

### When to Switch APIs
Consider migrating to a paid/official API when:
- Project moves to production
- Commercial use is required
- Guaranteed uptime is needed
- Official support is necessary
- Legal concerns about unofficial API usage arise

---

## Support & Resources

### Community Resources
- **GitHub Gist:** https://gist.github.com/nntrn/ee26cb2a0716de0947a0a4e9a157bc1c
- **Public ESPN API Docs:** https://github.com/pseudo-r/Public-ESPN-API

### Testing Tools
- **Postman:** Test endpoints interactively
- **cURL:** Command-line testing
- **Browser DevTools:** Inspect network requests on ESPN.com

### Monitoring
- Monitor ESPN.com for changes that might affect API
- Join developer communities discussing ESPN API
- Have backup plan (MySportsFeeds) ready if API breaks

---

**Document Version:** 1.0  
**Last Updated:** October 18, 2025  
**Next Review:** Before production deployment

---

*This research document is provided for validation/testing purposes. The ESPN API is unofficial and unsupported. For production applications, consider official alternatives like MySportsFeeds (non-commercial) or SportsDataIO/Sportradar (commercial).*
