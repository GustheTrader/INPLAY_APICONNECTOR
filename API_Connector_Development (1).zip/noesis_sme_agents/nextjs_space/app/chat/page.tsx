
import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { authOptions } from '@/lib/auth'
import { ChatInterface } from '@/components/chat/chat-interface'

export default async function ChatPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect('/auth/signin')
  }

  return (
    <div className="h-screen bg-gradient-to-br from-background to-muted/20">
      <ChatInterface />
    </div>
  )
}
